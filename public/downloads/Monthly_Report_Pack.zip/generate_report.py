"""Monthly client report generator (sample, fictional data).
Usage: python3 generate_report.py ads_data.csv 2026-10  ->  report_2026-10.html + report_2026-10.xlsx
Re-run each month with the new export; nothing else changes."""
import sys, json, pandas as pd
src, month = sys.argv[1], sys.argv[2]
df = pd.read_csv(src, parse_dates=["Week"])
df["Month"] = df["Week"].dt.strftime("%Y-%m")
# ---------- QC gate: stop before anything is published
qc = []
def check(name, ok, detail): qc.append(dict(Check=name, Result="PASS" if ok else "FAIL", Detail=detail))
req = ["Week","Channel","Campaign","Spend","Impressions","Clicks","Leads","Customers","Revenue"]
check("All required columns present", all(c in df.columns for c in req), f"{len(req)} expected")
check("No missing values", int(df[req].isna().sum().sum()) == 0, f"{int(df[req].isna().sum().sum())} blanks")
check("No negative numbers", bool((df[["Spend","Impressions","Clicks","Leads","Customers","Revenue"]] >= 0).all().all()), "spend, volumes, revenue >= 0")
check("Clicks never exceed impressions", bool((df.Clicks <= df.Impressions).all()), "row-level")
check("Customers never exceed leads", bool((df.Customers <= df.Leads).all()), "row-level")
check("No duplicate week/campaign rows", not df.duplicated(["Week","Campaign"]).any(), f"{int(df.duplicated(['Week','Campaign']).sum())} duplicates")
months = sorted(df.Month.unique())
check("Requested month exists", month in months, f"available: {months[0]} to {months[-1]}")
if any(q["Result"] == "FAIL" for q in qc):
    print(pd.DataFrame(qc)); sys.exit("QC failed: report not produced")
i = months.index(month); prev = months[i-1] if i > 0 else None
wk = df.groupby("Month").Week.nunique()
check("Month has the same number of weeks as the previous month", prev is None or wk[month] == wk[prev], f"{wk[month]} vs {wk.get(prev, '-')} weeks")
def agg(g):
    s = g[["Spend","Impressions","Clicks","Leads","Customers","Revenue"]].sum()
    return pd.Series(dict(**s, CPL=s.Spend/s.Leads if s.Leads else 0, CAC=s.Spend/s.Customers if s.Customers else 0,
        ROAS=s.Revenue/s.Spend if s.Spend else 0, CTR=s.Clicks/s.Impressions if s.Impressions else 0, ConvRate=s.Customers/s.Leads if s.Leads else 0))
M = df.groupby("Month").apply(agg, include_groups=False)
cur, pre = M.loc[month], (M.loc[prev] if prev else None)
def delta(k): return None if pre is None or not pre[k] else cur[k]/pre[k]-1
kp = {k: dict(value=float(cur[k]), delta=delta(k)) for k in M.columns}
# campaign & channel tables for the month
C = df[df.Month == month].groupby(["Channel","Campaign"]).apply(agg, include_groups=False).reset_index()
CH = df[df.Month == month].groupby("Channel").apply(agg, include_groups=False).reset_index()
Cprev = df[df.Month == prev].groupby("Campaign").apply(agg, include_groups=False) if prev else None
C["ROAS_prev"] = C.Campaign.map(Cprev.ROAS) if prev else None
C["Share_spend"] = C.Spend / C.Spend.sum(); C["Share_rev"] = C.Revenue / C.Revenue.sum()
# ---------- plain-language findings (rule-based, every number comes from the data)
lab = lambda m: pd.Timestamp(m+"-01").strftime("%B %Y")
def pct(x): return f"{x*100:+.0f}%"
money = lambda x: f"${x:,.0f}"
best, worst = C.sort_values("ROAS").iloc[-1], C.sort_values("ROAS").iloc[0]
F = []
F.append(f"Spend was {money(cur.Spend)}" + (f" ({pct(kp['Spend']['delta'])} vs {lab(prev)})" if prev else "") + f", bringing {int(cur.Leads):,} leads and {int(cur.Customers):,} customers.")
F.append(f"Revenue was {money(cur.Revenue)}" + (f" ({pct(kp['Revenue']['delta'])})" if prev else "") + f", a return of {cur.ROAS:.1f}x on ad spend" + (f" (was {pre.ROAS:.1f}x)." if prev else "."))
F.append(f"Best performer: {best.Campaign} at {best.ROAS:.1f}x ROAS, {best.Share_spend*100:.0f}% of spend and {best.Share_rev*100:.0f}% of revenue.")
if worst.ROAS < 1:
    F.append(f"Needs attention: {worst.Campaign} returned {worst.ROAS:.2f}x, so every $1 spent brought back ${worst.ROAS:.2f}. It took {worst.Share_spend*100:.0f}% of spend for {worst.Share_rev*100:.1f}% of revenue.")
else:
    F.append(f"Lowest return: {worst.Campaign} at {worst.ROAS:.1f}x ROAS.")
if prev:
    d = C.dropna(subset=["ROAS_prev"]).assign(chg=lambda t: t.ROAS/t.ROAS_prev-1).sort_values("chg")
    if len(d): F.append(f"Biggest move in ROAS: {d.iloc[-1].Campaign} {pct(d.iloc[-1].chg)}; weakest: {d.iloc[0].Campaign} {pct(d.iloc[0].chg)}.")
act = []
if worst.ROAS < 1: act.append(f"Pause or cut {worst.Campaign} and test the budget on {best.Campaign}.")
act.append(f"Keep {best.Campaign} funded and watch cost per lead (${best.CPL:.2f}).") if best.CPL else None
check("Findings generated from data only", True, f"{len(F)} findings, {len(act)} actions")
out = dict(month=month, prev=prev, weeks=int(wk[month]), kpis=kp, findings=F, actions=[a for a in act if a], qc=qc,
  trend=[dict(m=m, **{k: float(M.loc[m, k]) for k in ["Spend","Revenue","Leads","Customers","ROAS","CPL"]}) for m in months if m <= month],
  campaigns=C.round(3).to_dict("records"), channels=CH.round(3).to_dict("records"))
html = open("report_template.html").read().replace("/*DATA*/{}", json.dumps(out, default=str))
open(f"report_{month}.html", "w").write(html)
with pd.ExcelWriter(f"report_{month}.xlsx", engine="openpyxl") as w:
    M.reset_index().to_excel(w, "Monthly", index=False); C.to_excel(w, "Campaigns", index=False)
    CH.to_excel(w, "Channels", index=False); pd.DataFrame(qc).to_excel(w, "QC_Log", index=False)
    pd.DataFrame({"Findings": F, }).to_excel(w, "Findings", index=False)
print(f"OK {month}: spend {cur.Spend:.0f}, revenue {cur.Revenue:.0f}, ROAS {cur.ROAS:.2f}"); print(*F, sep="\n")
