Monthly Marketing Report generator (sample, fictional data)
Run each month with the new export:  python3 generate_report.py ads_data.csv 2026-10
Outputs: report_<month>.html (branded report), report_<month>.xlsx (data pack + QC log).
The script stops with no report if any data check fails.
Needs: Python 3, pandas, openpyxl.
